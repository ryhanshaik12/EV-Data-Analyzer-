
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

df = pd.read_csv("C:\\Users\\ryhan\\Desktop\\projects\\EV-Data-Explorer\\electric_vehicles_spec_2025.csv")


df["model"] = df["model"].fillna("Unknown model")
df["Vehicle"] = df["brand"] + " " + df["model"]


print("\n===== EV DATA ANALYZER =====")

print("Total vehicles:", len(df))
print("Different brands:", df["brand"].nunique())
print("Average driving range:", df["range_km"].mean().round(1), "km")
print("Average top speed:", df["top_speed_kmh"].mean().round(1), "km/h")
print(
    "Average energy consumption:",
    df["efficiency_wh_per_km"].mean().round(1),
    "Wh/km"
)


top_range = df.nlargest(10, "range_km")

print("\n===== TOP 10 BY RANGE =====")
print(top_range[["Vehicle", "range_km"]].to_string(index=False))


top_speed = df.nlargest(10, "top_speed_kmh")

print("\n===== TOP 10 BY TOP SPEED =====")
print(top_speed[["Vehicle", "top_speed_kmh"]].to_string(index=False))
top_charging = df.nlargest(10, "fast_charging_power_kw_dc")

print("\n===== TOP 10 BY CHARGING POWER =====")
print(
    top_charging[
        ["Vehicle", "fast_charging_power_kw_dc"]
    ].to_string(index=False)
)


fig, axes = plt.subplots(2, 2, figsize=(15, 10))


axes[0, 0].barh(top_range["Vehicle"], top_range["range_km"])
axes[0, 0].set_title("Top 10 EVs by Driving Range")
axes[0, 0].set_xlabel("Range (km)")

axes[0, 1].barh(top_speed["Vehicle"], top_speed["top_speed_kmh"])
axes[0, 1].set_title("Top 10 EVs by Top Speed")
axes[0, 1].set_xlabel("Top Speed (km/h)")


axes[1, 0].barh(
    top_charging["Vehicle"],
    top_charging["fast_charging_power_kw_dc"]
)
axes[1, 0].set_title("Top 10 EVs by Fast-Charging Power")
axes[1, 0].set_xlabel("Charging Power (kW)")


axes[1, 1].scatter(
    df["battery_capacity_kWh"],
    df["range_km"]
)
axes[1, 1].set_title("Battery Capacity vs Driving Range")
axes[1, 1].set_xlabel("Battery Capacity (kWh)")
axes[1, 1].set_ylabel("Driving Range (km)")

plt.tight_layout()
plt.show()
